package cli

import "github.com/spf13/cobra"

func GetTxCmd() *cobra.Command {
	return nil
}
