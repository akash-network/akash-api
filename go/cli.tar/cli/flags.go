package cli

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/cosmos/cosmos-sdk/crypto/keyring"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"

	cmcli "github.com/cometbft/cometbft/libs/cli"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/x/params/types/proposal"

	client "pkg.akt.dev/go/node/client/v1beta3"
)

const (
	// DefaultGasAdjustment is applied to gas estimates to avoid tx execution
	// failures due to state changes that might occur between the tx simulation
	// and the actual run.
	DefaultGasAdjustment = 1.0
	DefaultGasLimit      = 200000
	GasFlagAuto          = "auto"

	DefaultKeyringBackend = keyring.BackendOS

	// BroadcastSync defines a tx broadcasting mode where the client waits for
	// a CheckTx execution response only.
	BroadcastSync = "sync"
	// BroadcastAsync defines a tx broadcasting mode where the client returns
	// immediately.
	BroadcastAsync = "async"

	BroadcastBlock = "block"

	// SignModeDirect is the value of the --sign-mode flag for SIGN_MODE_DIRECT
	SignModeDirect = "direct"
	// SignModeLegacyAminoJSON is the value of the --sign-mode flag for SIGN_MODE_LEGACY_AMINO_JSON
	SignModeLegacyAminoJSON = "amino-json"
	// SignModeDirectAux is the value of the --sign-mode flag for SIGN_MODE_DIRECT_AUX
	SignModeDirectAux = "direct-aux"
	// SignModeEIP191 is the value of the --sign-mode flag for SIGN_MODE_EIP_191
	SignModeEIP191 = "eip-191"
)

const (
	FlagDeposit          = "deposit"
	FlagState            = "state"
	FlagOwner            = "owner"
	FlagDSeq             = "dseq"
	FlagGSeq             = "gseq"
	FlagOSeq             = "oseq"
	FlagProvider         = "provider"
	FlagDepositorAccount = "depositor-account"
	FlagExpiration       = "expiration"
	FlagHome             = cmcli.HomeFlag
	FlagKeyringDir       = "keyring-dir"
	FlagUseLedger        = "ledger"
	FlagChainID          = "chain-id"
	FlagNode             = "node"
	FlagGRPC             = "grpc-addr"
	FlagGRPCInsecure     = "grpc-insecure"
	FlagHeight           = "height"
	FlagGasAdjustment    = "gas-adjustment"
	FlagFrom             = "from"
	FlagName             = "name"
	FlagAccountNumber    = "account-number"
	FlagSequence         = "sequence"
	FlagNote             = "note"
	FlagFees             = "fees"
	FlagGas              = "gas"
	FlagGasPrices        = "gas-prices"
	FlagBroadcastMode    = "broadcast-mode"
	FlagDryRun           = "dry-run"
	FlagGenerateOnly     = "generate-only"
	FlagOffline          = "offline"
	FlagOutputDocument   = "output-document" // inspired by wget -O
	FlagSkipConfirmation = "yes"
	FlagProve            = "prove"
	FlagKeyringBackend   = "keyring-backend"
	FlagPage             = "page"
	FlagLimit            = "limit"
	FlagSignMode         = "sign-mode"
	FlagPageKey          = "page-key"
	FlagOffset           = "offset"
	FlagCountTotal       = "count-total"
	FlagTimeoutHeight    = "timeout-height"
	FlagKeyType          = "key-type"
	FlagFeePayer         = "fee-payer"
	FlagFeeGranter       = "fee-granter"
	FlagReverse          = "reverse"
	FlagTip              = "tip"
	FlagAux              = "aux"
	FlagInitHeight       = "initial-height"
	FlagDelayed          = "delayed"
	// FlagOutput is the flag to set the output format.
	// This differs from FlagOutputDocument that is used to set the output file.
	FlagOutput = cmcli.OutputFlag

	// Tendermint logging flags
	FlagLogLevel     = "log_level"
	FlagLogFormat    = "log_format"
	FlagLogNoColor   = "log_no_color"
	FlagLogColor     = "log_color"
	FlagLogTimestamp = "log_timestamp"
)

var (
	ErrUnknownSubspace = errors.New("unknown subspace")
)

type paramCoin struct {
	Denom  string
	Amount string
}

type paramCoins []paramCoin

func AddDepositFlags(flags *pflag.FlagSet) {
	flags.String(FlagDeposit, "", "Deposit amount")
}

func DetectDeposit(ctx context.Context, flags *pflag.FlagSet, cl client.QueryClient, subspace, paramKey string) (sdk.Coin, error) {
	var deposit sdk.Coin
	var depositStr string
	var err error

	if !flags.Changed(FlagDeposit) {
		res, err := cl.Params().Params(ctx, &proposal.QueryParamsRequest{
			Subspace: subspace,
			Key:      paramKey,
		})
		if err != nil {
			return sdk.Coin{}, err
		}

		switch subspace {
		case "market":
			var coin paramCoin

			if err = json.Unmarshal([]byte(res.Param.Value), &coin); err != nil {
				return sdk.Coin{}, err
			}

			depositStr = fmt.Sprintf("%s%s", coin.Amount, coin.Denom)
		case "deployment":
			var coins paramCoins

			if err = json.Unmarshal([]byte(res.Param.Value), &coins); err != nil {
				return sdk.Coin{}, err
			}

			// always default to AKT
			for _, sCoin := range coins {
				if sCoin.Denom == "uakt" {
					depositStr = fmt.Sprintf("%s%s", sCoin.Amount, sCoin.Denom)
					break
				}
			}
		default:
			return sdk.Coin{}, ErrUnknownSubspace
		}

		if depositStr == "" {
			return sdk.Coin{}, fmt.Errorf("couldn't query default deposit amount for uAKT")
		}
	} else {
		depositStr, err = flags.GetString(FlagDeposit)
		if err != nil {
			return sdk.Coin{}, err
		}
	}

	deposit, err = sdk.ParseCoinNormalized(depositStr)
	if err != nil {
		return sdk.Coin{}, err
	}

	return deposit, nil
}

func MarkReqDepositFlags(cmd *cobra.Command) {
	_ = cmd.MarkFlagRequired(FlagDeposit)
}
